# pgf-umlcd

![CI](https://github.com/pgf-tikz/pgf/workflows/CI/badge.svg)

Some LaTeX macros for UML Class Diagrams.

Please go to the official repository at https://github.com/pgf-tikz/pgf-umlcd
or the official mailing list at https://tug.org/mailman/listinfo/pgf-tikz to
submit bug reports, request new features, etc.

Please read pgf-umlcd-manual.pdf for more information.

## License

pgf-umlcd is released under the terms of both the LPPL v1.3c and the GPL v2.
